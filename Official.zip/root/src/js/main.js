document.getElementById('oauth-button').addEventListener('click', function() {
    window.oauth2.start();
});
